var offcanvasElementList = [].slice.call(document.querySelectorAll('.offcanvas'))
var offcanvasList = offcanvasElementList.map(function(offcanvasEl) {
    return new bootstrap.Offcanvas(offcanvasEl)
})